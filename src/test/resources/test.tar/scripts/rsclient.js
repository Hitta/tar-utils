// Panorama viewer by CycloMedia
// Authors: SBr, Roo, JBr

/**
* loads recording locations from CycloMedia WFS service
* results are stored in the recordingList. Coordinates 
* of recordinglocations are in Web mercator format

// ?

*/
function RSClient(baseURL_, proxy_)
{
	this.baseURL = baseURL_;
	this.typename = "atlas:Recording";
	this.srsName = "EPSG:4258";
    this.localProxy = proxy_;
    this.useProxy = true;
    
    var that = this;
    
    this.getFeature = function (featureId, callback)
    {
        var postData = "\
            <wfs:GetFeature service=\"WFS\" version=\"1.1.0\" resultType=\"results\" outputFormat=\"text/xml; subtype=gml/3.1.1\" xmlns:wfs=\"http://www.opengis.net/wfs\">\
                <wfs:Query typeName=\"atlas:Recording\" srsName=\"##SRSNAME##\" xmlns:atlas=\"http://www.cyclomedia.com/atlas\">\
                    <ogc:Filter xmlns:ogc=\"http://www.opengis.net/ogc\">\
                        <ogc:FeatureId fid=\"##FEATUREID##\"/>\
                    </ogc:Filter>\
                </wfs:Query>\
            </wfs:GetFeature>";
        
        postData = postData.replace("##FEATUREID##", featureId);
        postData = postData.replace(new RegExp("##SRSNAME##", "g"), this.srsName);
        
        createAndSendXMLHttpRequest(postData, callback);
    }
        
    this.getBBOX = function(left, bottom, right, top, callback)
    {
        var postData = "\
            <wfs:GetFeature service=\"WFS\" version=\"1.1.0\" resultType=\"results\" outputFormat=\"text/xml; subtype=gml/3.1.1\" xmlns:wfs=\"http://www.opengis.net/wfs\">\
                <wfs:Query typeName=\"##TYPENAME##\" srsName=\"##SRS##\" xmlns:atlas=\"http://www.cyclomedia.com/atlas\">\
                    <ogc:Filter xmlns:ogc=\"http://www.opengis.net/ogc\">\
                        <ogc:And>\
                            <ogc:BBOX>\
                                <gml:Envelope srsName=\"##SRS##\" xmlns:gml=\"http://www.opengis.net/gml\">\
                                    <gml:lowerCorner>##LEFT## ##BOTTOM##</gml:lowerCorner>\
                                    <gml:upperCorner>##RIGHT## ##TOP##</gml:upperCorner>\
                                </gml:Envelope>\
                            </ogc:BBOX>\
                            <ogc:PropertyIsNull>\
                                <ogc:PropertyName>expiredAt</ogc:PropertyName>\
                            </ogc:PropertyIsNull>\
                        </ogc:And>\
                    </ogc:Filter>\
                </wfs:Query>\
            </wfs:GetFeature>";
                        
        postData = postData.replace("##TYPENAME##", this.typename);
        postData = postData.replace(new RegExp("##SRS##", "g"), this.srsName);
        postData = postData.replace("##LEFT##", left);
        postData = postData.replace("##BOTTOM##", bottom);	
        postData = postData.replace("##RIGHT##", right);
        postData = postData.replace("##TOP##", top);		

        createAndSendXMLHttpRequest(postData, callback);
    }
    
    this.getRadius = function()
    {
        var lon = arguments[0];
        var lat = arguments[1];
        var distance = arguments[2]
        var callback = arguments[3];
        var maxFeatures = arguments.length === 5 ? "maxFeatures=\"" + arguments[4] + "\"" : "";
    
        var postData = "\
            <wfs:GetFeature service=\"WFS\" version=\"1.1.0\" resultType=\"results\" outputFormat=\"text/xml; subtype=gml/3.1.1\" ##MAXFEATURES## xmlns:wfs=\"http://www.opengis.net/wfs\">\
                <wfs:Query typeName=\"##TYPENAME##\" srsName=\"##SRS##\" xmlns:atlas=\"http://www.cyclomedia.com/atlas\">\
                    <ogc:Filter xmlns:ogc=\"http://www.opengis.net/ogc\">\
                        <ogc:And>\
                            <ogc:DWithin>\
                                <ogc:PropertyName>Recording/location</ogc:PropertyName>\
                                <gml:Point srsName=\"##SRS##\" xmlns:gml=\"http://www.opengis.net/gml\">\
                                    <gml:pos>##LON## ##LAT##</gml:pos>\
                                </gml:Point>\
                                <ogc:Distance units=\"http://www.opengeospatial.org/se/units/metre\">##DISTANCE##</ogc:Distance>\
                            </ogc:DWithin>\
                            <ogc:PropertyIsNull>\
                                <ogc:PropertyName>expiredAt</ogc:PropertyName>\
                            </ogc:PropertyIsNull>\
                        </ogc:And>\
                    </ogc:Filter>\
                </wfs:Query>\
            </wfs:GetFeature>";
        
        postData = postData.replace("##MAXFEATURES##", maxFeatures);
        postData = postData.replace("##TYPENAME##", this.typename);
        postData = postData.replace(new RegExp("##SRS##", "g"), this.srsName);
        postData = postData.replace("##DISTANCE##", distance);
        postData = postData.replace("##LON##", lon);
        postData = postData.replace("##LAT##", lat);
        
        createAndSendXMLHttpRequest(postData, callback);
    }
    
    function createAndSendXMLHttpRequest(postData, callback)
    {
        var url = that.localProxy + that.baseURL;
        var request = new XMLHttpRequest();
        
        //Send the proper header information along with the request
        //http.setRequestHeader("Content-length", postData.length);

        var timeoutReference = setTimeout( function() { request.abort(); }, 100000 );
        
        request.onreadystatechange = function() 
        {
            if(request.readyState != 4)
                return;
        
            clearTimeout(timeoutReference);
        
            var fts;
        
            if(request.status == 200)
            {
                fts = that.parse(request.responseText);
            }
            else
            {
                // error
                fts = new List();
            }
            
            callback(fts);
        }
        
        request.open("POST", url , true);
        request.send(postData);
    }
}

// http://www.gal-systems.com/2011/07/convert-coordinates-between-web.html
RSClient.prototype.geogToWebMercator = function(lon, lat) 
{	
    var Rad = lat * (Math.PI / 180);
    var FSin = Math.sin(Rad);

    var p = Vector.create([
        lon * 0.017453292519943 * 6378137.0,
        6378137 / 2.0 * Math.log((1.0 + FSin) / (1.0 - FSin))
    ]);
        
    return p;
}

RSClient.prototype.parse = function(xml)
{ 
    // Do the parsing stuff
	var parseXml;

	if (typeof window.DOMParser != "undefined") 
	{
	    parseXml = function(xmlStr) 
	    {
	        return ( new window.DOMParser() ).parseFromString(xmlStr, "text/xml");
	    };
	} 
	else if (typeof window.ActiveXObject != "undefined" && new window.ActiveXObject("Microsoft.XMLDOM")) 
    {
        parseXml = function(xmlStr) 
        {
            var xmlDoc = new window.ActiveXObject("Microsoft.XMLDOM");
            xmlDoc.async = "false";
            xmlDoc.loadXML(xmlStr);
            
            return xmlDoc;
        };
    } 
	else 
	{
	    throw new Error("No XML parser found");
	}
	
    var xml = parseXml(xml);
    var recordings = xml.getElementsByTagNameNS("*","Recording");
     
    // Create new list for recordings
    var recordingList = new List();
       
    for(var i = 0; i < recordings.length; i++)
	{		
		var imageId = xml.getElementsByTagNameNS("*", "imageId")[i].firstChild.data;
		var pos = xml.getElementsByTagNameNS("*", "pos")[i].firstChild.data;
        var lonlat = pos.split(" ");
        var lon = parseFloat(lonlat[0]);
        var lat = parseFloat(lonlat[1]);
        var p = Vector.create([lon, lat]);
		var pp = this.geogToWebMercator(lon, lat);
        
        p.elements.push(0.0);
        pp.elements.push(0.0);
        
		var t = new Recording(imageId, p, pp);
        
		recordingList.Add(t);
	}
    
    return recordingList;
}

// Position of a recording location
function Recording(id, p, pp)
{    
    this.id = id;
    this.position = p.dup();
    this.projectedPosition = pp.dup();
}