// Panorama viewer by CycloMedia
// Authors: SBr, Roo, JBr

/*

TODO:
    
    - Layer
        
    - Events/Callbacks
    - openImageID

    - Error handling
    - Size handling on resize event instead of per frame render
    - Current size request seems slow
    
    - Constants in class or object?
    
*/

var CCLMD = 
{
    VIEWER_TYPE_2D : "2d",
    VIEWER_TYPE_CSS3 : "css3",
    VIEWER_TYPE_WEBGL : "webgl",
    VIEWER_TYPE_UNDEFINED : "undefined",
    createPanoramaViewer : function(idViewerContainer) { return new PanoramaViewer(idViewerContainer); }
}

// PanoramaViewer
function PanoramaViewer(idViewerContainer, useLocalFiles)
{
    // **************************************************************************************************
    // Constants
    // **************************************************************************************************
    
    var DEG_TO_RAD = Math.PI / 180.0;
    var DEFAULT_VIEWER_WIDTH = 512;
    var DEFAULT_VIEWER_HEIGHT = 384;
    var HFOV_DEF = 90.0 * DEG_TO_RAD;
    var HFOV_MAX = 130.0 * DEG_TO_RAD;
    var HFOV_MIN = 30.0 * DEG_TO_RAD;
    var RECORDING_REQUEST_RADIUS = 7.0;
    
    var that = this;
    
    // Browser dependend prefixes for styles.
    var stylePropertyPrefixes = ["", "Webkit", "Moz", "O", "ms", "Ms"];
    var stylePropertyPrefix;
    var cssPropertyPrefixes = ["", "-webkit-", "-moz-", "-o-", "-ms-", "-ms-"];
    var cssPropertyPrefix;
    var propertyPropertyPrefixes = ["", "webkit", "moz", "o", "ms", "ms"];
    
    getPrefixes();
        
    // **************************************************************************************************
    // Viewer properties and factory
    // **************************************************************************************************
        
    var viewerContainer = document.getElementById(idViewerContainer);
    var viewer = null;
    var viewerType = CCLMD.VIEWER_TYPE_UNDEFINED;
    
    // The one function that is always available and queriable.
    this.getViewerType = function() { return viewerType; }
    
    if(viewerContainer == null)
    {
        alert("Component with id \"" + idViewerContainer + "\" does not exist.");
        
        // Early out
        return;
    }
    
    if(supportsCanvas() == false)
    {
        viewerContainer.appendChild(document.createTextNode("Your browser does not appear to support the required HTML5 CANVAS element."));
        
        // Early out
        return;
    }
    
    var width = getViewerWidth();
    var height = getViewerHeight();
    
    // M = Mobile, D = Desktop
        
    // Active request for animation
    var animationFrameID = -1;
            
    /*if(supportsWebGL())
    {
        viewer = new WebGLViewer(width, height);
        viewerType = CCLMD.VIEWER_TYPE_WEBGL;
    }
    else */if(supportsCSS3())
    {
        viewer = new CSS3Viewer(width, height);
        viewerType = CCLMD.VIEWER_TYPE_CSS3;
    }
    // D : Internet Explorer
    else if(supportsCanvas())
    {
        viewer = new Canvas2DViewer(width, height);
        viewerType = CCLMD.VIEWER_TYPE_2D;
    }
    else
    {
        viewerContainer.appendChild(document.createTextNode("Your browser does not appear to support any of the required HTML5/WebGL/CSS3 capabilities."));
        
        // Early out
        return;
    }
    
    /**
    * Minor full-screen API handler. It has a value of null if not available. It only exposes 
    * those functions that are available on all browsers that support full-screen (join).
    */
    var fullScreenHandler = (function() 
    {    
        // The interface as defined by w3:
        //      http://dvcs.w3.org/hg/fullscreen/raw-file/tip/Overview.html#api
        
        // Check for a common property that should be available if full-screen is available.
        var prefix = getPropertyPrefix(document, "fullScreenElement");
        var properties;
        
        switch(prefix)
        {
            case "":
                // The "official" standard.
                properties = {
                    requestFullscreen : "requestFullscreen",
                    exitFullscreen : "exitFullscreen",                 
                    fullscreenElement : "fullscreenElement",
                    //fullscreenEnabled: "fullscreenEnabled",
                    fullscreenchange : "fullscreenchange",
                    fullscreenerror : "fullscreenerror"
                };
                break;
            case "moz":
                properties = {
                    requestFullscreen : "mozRequestFullScreen",
                    exitFullscreen : "mozCancelFullScreen",
                    fullscreenElement : "mozFullScreenElement",
                    fullscreenchange : "mozfullscreenchange",
                    fullscreenerror : "mozfullscreenerror"
                };
                break;
            case "webkit":
                properties = {
                    requestFullscreen : "webkitRequestFullScreen",
                    exitFullscreen : "webkitCancelFullScreen",
                    fullscreenElement : "webkitFullScreenElement",
                    fullscreenchange : "webkitfullscreenchange",
                    fullscreenerror : "webkitfullscreenerror"
                };
                break;            
        }

        var api;
        
        if(properties != null)
        {
            // The full-screen API with function names equal to those defined by wc3.
            api = {
                // Displays element fullscreen. 
                requestFullscreen : function (element) { element[properties.requestFullscreen](); },
                // Stops any elements within document from being displayed fullscreen. 
                exitFullscreen : document[properties.exitFullscreen],
                         
                // NOT an official property by w3c. However, Mozilla and WebKit did add it...
                // This is an adaptation due to lack of compatibility.
                // Returns true if the document is currently displaying an element in full-screen mode.
                isFullscreen : function() { return document[properties.fullscreenElement] != null; },
                // Returns the element that is displayed fullscreen, or null if there is no such element. 
                fullscreenElement : document[properties.fullscreenElement],
                
                // Returns true if document has the ability to display elements fullscreen, or false otherwise. 
                // NOT available in webkit, thus we cannot use it in our API ...
                //fullscreenEnabled : document[properties.fullscreenEnabled],
                
                onfullscreenchange : function(event) { },
                onfullscreenerror : function(event) { }
            };
            
            document.addEventListener
            (
                properties.fullscreenchange, 
                function( event )
                {
                    api.fullscreenElement = document[ properties.fullscreenElement ];
                    api.onfullscreenchange.call( api, event );
                }
            );

            document.addEventListener
            ( 
                properties.fullscreenerror, 
                function( event )
                {
                    api.onfullscreenerror.call( api, event );
                }
            );
        }
        
        return api;
    }());
    
    if(fullScreenHandler)
    {
        // To ensure we get the right width and height for this viewer...
        fullScreenHandler.onfullscreenchange = function (event) {
            width = getViewerWidth();
            height = getViewerHeight();
            requestAnimationFrame();
        }
    }
    
    // The wrapper is used for positioning all viewer components at once. Without it, it is difficult 
    // to move all components relative to each other in case the website developer uses a border, padding, 
    // etc for the viewer container.
    var contentWrapper = document.createElement("div");
    contentWrapper.setAttribute("style", 
        "position:absolute;" +
        cssPropertyPrefix + "user-select: none;"
    );
    
    var layer = document.createElement("canvas");     
    layer.setAttribute("style", 
        "position:absolute;" +
        "left:0px;" +
        "top:0px;" +
        cssPropertyPrefix + "user-select: none;"
    );
    var rlsDrawer = new ArrowDrawer(layer);
    rlsDrawer.onmarkerclick = function(recording) 
    { 
        openImageFromRecording(recording); 
        loadCubeFaces.apply(this, [recording.id]); 
        
        // Check for callback
        if(that.onimageload)
        {
            that.onimageload();
        }
    }
    
    var fps = document.createTextNode("");
    var fpsContainer = document.createElement("div");
    fpsContainer.setAttribute("style", 
        "position:absolute;" +
        "left:20px;" +
        "top:20px;" +
        cssPropertyPrefix + "user-select: none;"
    );
    fpsContainer.appendChild(fps);
                    
    contentWrapper.appendChild(viewer.domElement);
    contentWrapper.appendChild(layer);
    contentWrapper.appendChild(fpsContainer);
    viewerContainer.appendChild(contentWrapper);
    
    if(fullScreenHandler != null)
    {
        addStylesheetRules([
            [":" + cssPropertyPrefix + "full-screen" + " #contentWrapper", ["width", "100%"], ["height", "100%"]]
        ]);
    }
    
    var rsClient = new RSClient("https://atlas.cyclomedia.com/Recordings/wfs", "https://www.globespotter.nl/html5/atlasproxy.php?url=");
    
    //viewerContainer.onresize = onResizeEvent;// only for window/doc?
            
    // **************************************************************************************************
    // Definition of viewer interface
    // **************************************************************************************************
    
    // The current image.
    var imageId;
    // The current recording or metadata of the viewed image.
    var recording;
        
    var useDeviceOrientation = false;
    var useDeviceMotion = false;
    
    this.getYaw = viewer.getYaw;
    this.setYaw = function(value) { viewer.setYaw(value); requestAnimationFrame(); };
    this.getPitch = viewer.getPitch;
    this.setPitch = function(value) { viewer.setPitch(value); requestAnimationFrame(); };
    this.getHFov = viewer.getHFov;
    this.setHFov = function(value) { viewer.setHFov(value); requestAnimationFrame(); };
    this.getVFov = function()
    {
        var hFov = viewer.getHFov();
        var vFov = Math.atan( height / ( width / ( Math.tan(hFov / 2.0) ) ) ) * 2.0;
        
        return vFov;
    };
    this.setVFov = function(value)
    {
        var hFov = Math.atan( width / ( height / ( Math.tan(value / 2.0) ) ) ) * 2.0;
        
        viewer.setHFov(hFov);
        
        requestAnimationFrame();
    };
    this.openImage = function()
    {
        recording = null;
    
        if(arguments.length === 1)
        {        
            rsClient.getFeature(
                arguments[0], 
                function (rls)
                {
                    if(rls.Count() === 1)
                    {
                        openImageFromRecording(rls.ElementAt(0));
                    }
                    else
                    {
                        alert("Error loading recording.");
                    }
                }
            );
        }
        else if(arguments.length != 6)
        {
            return;
        }
    
        loadCubeFaces.apply(this, arguments);
        // Check for callback
        if(that.onimageload)
        {
            that.onimageload();
        }
    };
    this.openNearestImage = function(lon, lat)
    {
        recording = null;
        
        rsClient.getRadius(lon, lat, 100,
            function (rls)
            {
                if(rls.Count() === 1)
                {
                    openImageFromRecording(rls.ElementAt(0));                 
                    loadCubeFaces.apply(this, [imageId]);
                }
                else
                {
                    alert("Error loading recording.");
                }
            },
            1
        );
	
        // Check for callback
        if(that.onimageload)
        {
            that.onimageload();
        }
    };
    this.getImageId = function() { return imageId; };
    /**
    * Returns true if the device motion sensor API is available through the browser.
    */
    this.deviceOrientationAvailable = function() { return window.DeviceOrientationEvent != undefined; };
    /**
    * Returns true if the device orientation sensor API is available through the browser.
    */
    this.deviceMotionAvailable = function() { return window.DeviceMotionEvent !== undefined; };
    /**
    * Returns true if the full-screen API is available through the browser.
    */
    this.fullScreenAvailable = function() { return fullScreenHandler != null; };
    /**
    * Returns true if the document is currently displaying an element in full-screen mode.
    */
    this.getFullScreen = function() { return this.fullScreenAvailable() && fullScreenHandler.isFullscreen(); };
    /**
    * Toggles full-screen. Note that it may not be possible to enter full-screen. An example would be that another
    * element is already in full-screen.
    */
    this.toggleFullScreen = function() 
    {  
        if(this.fullScreenAvailable())
        {
            if(fullScreenHandler.isFullscreen())
                fullScreenHandler.exitFullscreen();
            else
                fullScreenHandler.requestFullscreen(contentWrapper);
        }
    };
    this.getUseDeviceOrientation = function() { return useDeviceOrientation; };
    this.getUseDeviceMotion = function() { return useDeviceMotion; };
    this.setUseDeviceOrientation = function(value) { useDeviceOrientation = value; };
    this.setUseDeviceMotion = function(value) { useDeviceMotion = value; };
    /**
    * A callback function that is fired when loading a new panorama.
    */
    this.onimageload;
    /**
    * A callback function that is fired when the panorama is completely loaded.
    */
    this.onimageloaded;
    /**
    * A callback function that is fired when the panorama failed to load.
    */
    this.onimagefailed;
    /**
    * A callback function that is fired when the view of a panorama has changed.
    * @param yaw
    * @param pitch
    * @param hFov
    */
    this.onviewchanged;
    
    function openImageFromRecording(rl)
    {
        recording = rl;
        imageId = recording.id;
        rlsDrawer.camera.position = recording.projectedPosition.dup();
                                                        
        // Load recording bounds for the recording layer
        var x = recording.position.elements[0];
        var y = recording.position.elements[1];
        
        rsClient.getRadius(x, y, RECORDING_REQUEST_RADIUS, 
            function(rls) 
            {
                rlsDrawer.setRecordings(rls);
                //requestAnimationFrame();
            }
        );
    }
    
    
    // **************************************************************************************************
    // Cube face loading
    // **************************************************************************************************
    
    var facesLoaded = 0;
    var facesFailed = 0;
    var right, left, top, bottom, back, front;
            
    addInteractionListeners();
    
    // **************************************************************************************************
    // Utility
    // **************************************************************************************************
    
    function getPrefixes()
    {
        // assume user-select is popular
        
        for (var i = 0; i < stylePropertyPrefixes.length; i++) 
        {
            if(typeof document.documentElement.style[stylePropertyPrefixes[i] + "UserSelect"] !== "undefined")
            {
                stylePropertyPrefix = stylePropertyPrefixes[i];
                cssPropertyPrefix = cssPropertyPrefixes[i];
                functionPropertyPrefix = propertyPropertyPrefixes[i];
                return;
            }
        }
    }
    
    function supportsCSS3()
    {    
        // Assume the browser can handle CSS3 3D transforms when the "perspective" style is available.
        if(typeof document.documentElement.style[stylePropertyPrefix + "Perspective"] !== "undefined")
            return true;
        
        return false;
    }
    
    function supportsWebGL()
    {    
        // Create canvas and attempt to obtain webgl context.
        var c = document.createElement("canvas");
        var w;
        
        try
        {
            // Try to grab the standard context. If it fails, fallback to experimental.  
            w = c.getContext !== undefined ? c.getContext("webgl") || c.getContext("experimental-webgl") : null;
        }
        catch(e)
        {
            // -
        }
        
        return w != null;
    }
    
    function supportsCanvas()
    {    
        // Create canvas and attempt to obtain 2d context.
        var c = document.createElement("canvas");
        var b = c.getContext !== undefined;
        
        c = null;
        
        return b;
    }
    
    /**
     * Add a stylesheet rule to the document (may be better practice, however,
     *  to dynamically change classes, so style information can be kept in
     *  genuine styesheets (and avoid adding extra elements to the DOM))
     * Note that an array is needed for declarations and rules since ECMAScript does
     * not afford a predictable object iteration order and since CSS is
     * order-dependent (i.e., it is cascading); those without need of
     * cascading rules could build a more accessor-friendly object-based API.
     * @param {Array} decls Accepts an array of JSON-encoded declarations
     * @example
    addStylesheetRules([
      ['h2', // Also accepts a second argument as an array of arrays instead
        ['color', 'red'],
        ['background-color', 'green', true] // 'true' for !important rules
      ],
      ['.myClass',
        ['background-color', 'yellow']
      ]
    ]);
     */
    function addStylesheetRules (decls) {
        var style = document.createElement('style');
        document.getElementsByTagName('head')[0].appendChild(style);
        if (!window.createPopup) { /* For Safari */
           style.appendChild(document.createTextNode(''));
        }
        var s = document.styleSheets[document.styleSheets.length - 1];
        for (var i=0, dl = decls.length; i < dl; i++) {
            var j = 1, decl = decls[i], selector = decl[0], rulesStr = '';
            if (Object.prototype.toString.call(decl[1][0]) === '[object Array]') {
                decl = decl[1];
                j = 0;
            }
            for (var rl=decl.length; j < rl; j++) {
                var rule = decl[j];
                rulesStr += rule[0] + ':' + rule[1] + (rule[2] ? ' !important' : '') + ';\n';
            }
     
            if (s.insertRule) {
                s.insertRule(selector + '{' + rulesStr + '}', s.cssRules.length);
            }
            else { /* IE */
                s.addRule(selector, rulesStr, -1);
            }
        }
    }
    
    // Check for an element if it has a certain property.
    // Cross browser check based on fixed prefixes for experimental properties.
    function getProperty(element, p)
    {
        if( typeof element[p] !== "undefined" )
            return true;
        
        p = p.substr(0, 1).toUpperCase() + p.substr(1);
    
        for (var i = 0; i < propertyPropertyPrefixes.length; i++) 
        {
            if(typeof element[propertyPropertyPrefixes[i] + p] !== "undefined")
            {
                return element[propertyPropertyPrefixes[i] + p];
            }
        }
        
        return undefined;
    }
    
    function getPropertyPrefix(element, p)
    {
        if( typeof element[p] !== "undefined" )
            return "";
        
        p = p.substr(0, 1).toUpperCase() + p.substr(1);
        
        for (var i = 0; i < propertyPropertyPrefixes.length; i++) 
        {
            if(typeof element[propertyPropertyPrefixes[i] + p] !== "undefined")
            {
                return propertyPropertyPrefixes[i];
            }
        }
        
        return null;
    }
            
    /**
    * Requests cube faces. If there is one parameter, it is assumed to be an image id and we request the 
    * cube faces using a service. If there are 6 parameters, they are assumed to be the URLs of the cube
    * face images in the order of: righ, left, top, bottom, back and front.
    */
    function loadCubeFaces()
    {
        cubeSize = 0;
        facesLoaded = 0;
        facesFailed = 0;
    
        if(arguments.length === 1)
        {
            var imageId = arguments[0];
            
            // Fixed parameters.
            var url = "https://www.globespotter.nl/html5/image.php?imageid=";
            var size = 1024;
            
            right = loadCubeFace(url + imageId + "&size=" + size  + "&yaw=90&pitch=0&hfov=90");
            left = loadCubeFace(url + imageId + "&size=" + size  + "&yaw=270&pitch=0&hfov=90");
            top = loadCubeFace(url + imageId + "&size=" + size  + "&yaw=0&pitch=90&hfov=90");
            bottom = loadCubeFace(url + imageId + "&size=" + size  + "&yaw=0&pitch=-90&hfov=90");
            back = loadCubeFace(url + imageId + "&size=" + size  + "&yaw=180&pitch=0&hfov=90");
            front = loadCubeFace(url + imageId + "&size=" + size  + "&yaw=0&pitch=0&hfov=90");
        }
        else if(arguments.length === 6)
        {
            right = loadCubeFace(arguments[0]);
            left = loadCubeFace(arguments[1]);
            top = loadCubeFace(arguments[2]);
            bottom = loadCubeFace(arguments[3]);
            back = loadCubeFace(arguments[4]);
            front = loadCubeFace(arguments[5]);
        }
    }
    
    function loadCubeFace(fileName)
    {
        var img = new Image();
        img.onload = function() 
        {            
            if(cubeSize === 0)
                cubeSize = img.width;
         
            if(img.width !== img.height)
            {
                facesFailed++;
                //alert("Cube face dimensions do not match.");
            }
            else if(img.width !== cubeSize)
            {
                facesFailed++;
                //alert("Cube face dimensions do not match those of other faces.");
            }
                                    
            facesLoaded++;
            
            if(facesLoaded === 6)
            {
                if(facesFailed === 0)
                {
                    viewer.setCubeFaces(right, left, top, bottom, back, front);
                    requestAnimationFrame();
                    
                    if(that.onimageloaded)
                    {
                        that.onimageloaded();
                    }
                }
                else if(that.onimagefailed)
                {
                    that.onimagefailed();
                }
            }
        };
        img.onerror = function() 
        {
            facesFailed++;
            facesLoaded++;
            
            if(facesLoaded === 6 && that.onimagefailed)
            {
                that.onimagefailed();
            }
		}
        img.src = fileName;
        
        return img;
    }
    
    function requestAnimationFrame()
    {
        // Don't request a frame update if one was pending already.
        if(animationFrameID === -1)
        {
            animationFrameID = window.requestAnimationFrame(render, viewerContainer);
        }        
    }
    
    /**
    * Handles rendering of a frame. This method is never called directly, but via the browser agent 
    * after a request for animation.
    * <p/>
    * According to the official specification, there is a time argument: <br/>
    * http://dvcs.w3.org/hg/webperf/raw-file/tip/specs/RequestAnimationFrame/Overview.html
    */
    function render()
    {
        if(viewer === null)
            return;
        
        var s = (new Date()).getTime();
                        
        viewer.render(width, height);
        
        layer.width = width;
        layer.height = height;
                
        var yaw = viewer.getYaw();
        var pitch = viewer.getPitch();
        var hFov = viewer.getHFov();
        
        rlsDrawer.camera.update(width, height, yaw, pitch, hFov);
        rlsDrawer.draw();
        
        animationFrameID = -1;
        
        var e = (new Date()).getTime();
        
        // Render time in millis.
        var m = e - s;
        
        fps.data = m;
        
        if(that.onviewchanged)
        {
            that.onviewchanged(yaw, pitch, hFov);
        }
    }
    
    function getViewerWidth()
    {
        var element = viewerContainer;
        
        if(fullScreenHandler != null && fullScreenHandler.isFullscreen())
            element = contentWrapper;
    
        // If a style property was set, it gives the pixel size of the component, otherwise its default size.   
        return parseInt(window.getComputedStyle(element, null).width);
    }
    
    function getViewerHeight()
    {
        var element = viewerContainer;
                
        if(fullScreenHandler != null && fullScreenHandler.isFullscreen())
            element = contentWrapper;
    
        return parseInt(window.getComputedStyle(element, null).height);
    }
    
    function onResizeEvent(event)
    {
        width = getViewerWidth();
        height = getViewerHeight();
        requestAnimationFrame();
    }
    
    // **************************************************************************************************
    // User interaction with the viewer
    // **************************************************************************************************
    
    var isMoveInteracting = false;
    var isZoomInteracting = false;
    var interactionDownX = 0.0;
    var interactionDownY = 0.0;
    var interactionDownPitch = 0.0;
    var interactionDownYaw = 0.0;
    var interactionTouchZoomLength = 0.0;
    
    function addInteractionListeners()
    {
        viewerContainer.addEventListener("mousedown", onViewerMouseDown, false);
        
        document.addEventListener("mousemove", onDocumentMouseMove, false);
        document.addEventListener("mouseup", onDocumentMouseUp, false);
        document.addEventListener("mouseout", onDocumentMouseOut, false);
                
        viewerContainer.addEventListener("mousewheel", onViewerMouseWheel, false);
        viewerContainer.addEventListener("DOMMouseScroll", onViewerMouseWheel, false);
        
        viewerContainer.addEventListener("touchstart", onViewerTouchStart, false);
        viewerContainer.addEventListener("touchmove", onDocumentTouchMove, false);
        viewerContainer.addEventListener("touchend", onViewerTouchEnd, false);
        viewerContainer.addEventListener("touchcancel", onViewerTouchCancel, false);
        viewerContainer.addEventListener("gestureend", onViewerGestureEnd, false);
        
        //viewerContainer.setAttribute("onresize", "alert('blaat');");//onResizeEvent, false);
        
        if (window.DeviceOrientationEvent)
			window.ondeviceorientation = onViewerDeviceOrientation;

		if (window.DeviceMotionEvent)
			window.ondevicemotion = onViewerDeviceMotion;
    }
    
    function onViewerMouseDown(event)
    {    
        down(event.pageX, event.pageY);
    }
    
    function onDocumentMouseMove(event)
    {    
        move(event.pageX, event.pageY);
    }
            
    function onDocumentMouseUp(event)
    {
        isMoveInteracting = false;
    }
    
    /**
    * Checks if the mouse leaves the web page and cancels interaction if the mouse has left the web page.
    */
    function onDocumentMouseOut(event)
    {        
        if( !(event.relatedTarget || event.toElement) )
        {
            isMoveInteracting = false;
        }
    }
    
    function onViewerMouseWheel(event)
    {
        var hFov = viewer.getHFov();
        var oldhFov = hFov;
        
        // The isZoomInteracting boolean is required due to numeric stability.
        if(isMoveInteracting == false && isZoomInteracting == false)
        {
            startInteraction(event.pageX, event.pageY);
            isZoomInteracting = true;
        }
        
        // WebKit
        if(event.wheelDeltaY) 
        {
            hFov -= (event.wheelDeltaY * 0.05) * DEG_TO_RAD;
        } 
        // Opera / Explorer 9
        else if(event.wheelDelta) 
        {
            hFov -= (event.wheelDelta * 0.05) * DEG_TO_RAD;
        }
        // Firefox
        else if(event.detail) 
        {
            hFov += (event.detail * 1.0) * DEG_TO_RAD;
        }
        
        viewer.setHFov(hFov);
        
        if(oldhFov !== viewer.getHFov())
        {
            var p = getPagePosition(contentWrapper);
            var x = event.pageX - p.x;
            var y = event.pageY - p.y;
            var oldvFov = oldhFov * ( height / width );
            var vFov = hFov * ( height / width );
            var yaw = viewer.getYaw() + (((( width / 2.0 ) - x ) / width ) /* ( _view.hFov)*/) * ( hFov - oldhFov );
            var pitch = viewer.getPitch() + (((( height / 2.0 ) - ( height - y )) / height ) /* (_view.vFov)*/) * ( vFov - oldvFov );
            
            viewer.setYaw(yaw);
            viewer.setPitch(pitch);
            requestAnimationFrame();
		}
    }
    
    function onViewerTouchStart(event) 
    {
        event.preventDefault();

        interactionTouchZoomLength = 0.0;
        
        if(event.touches.length === 1)
        {
            down(event.touches[0].pageX, event.touches[0].pageY);
        }
    }

    function onDocumentTouchMove(event) 
    {
        if(event.touches.length === 1)
        {
            move(event.touches[0].pageX, event.touches[0].pageY);
        }
        else if(event.touches.length > 1)
        {
            // zoom
            var x1 = event.touches[0].pageX
            var y1 = event.touches[0].pageY;
            var x2 = event.touches[1].pageX;
            var y2 = event.touches[1].pageY;

            var l = Math.sqrt(Math.pow(Math.abs(x1 - x2), 2) + Math.pow(Math.abs(y1 - y2), 2));    
            var oldhFov = viewer.getHFov();
                    
            if (Math.abs(l - interactionTouchZoomLength) != l) 
            {
                viewer.setHFov(viewer.getHFov() + (interactionTouchZoomLength - l) * DEG_TO_RAD * 0.5);
            }

            interactionTouchZoomLength = l;
            
            if(oldhFov !== viewer.getHFov())
            {
                var p = getPagePosition(contentWrapper);
                var x = (event.touches[0].pageX + event.touches[1].pageX) / 2 - p.x;
                var y = (event.touches[0].pageY + event.touches[1].pageY) / 2 - p.y;
                var oldvFov = oldhFov * ( height / width);
                var vFov = viewer.getHFov() * ( height / width );
                var yaw = viewer.getYaw() + (((( width / 2.0 ) - x ) / width) )*( viewer.getHFov() - oldhFov);
                var pitch = viewer.getPitch() + (((( height / 2.0 ) - ( height - y)) / height) ) * (vFov - oldvFov);
                        
                viewer.setYaw(yaw);
                viewer.setPitch(pitch);
                requestAnimationFrame();
            }
        }
    }

    function onViewerTouchEnd(event)
    {		
        isMoveInteracting = false;
    }

    function onViewerTouchCancel(event)
    {
        isMoveInteracting = false;
    }

    function onViewerGestureEnd(event)
    {
        isMoveInteracting = false;
    }
   
    function onViewerDeviceMotion(event) 
    {
		if (useDeviceMotion) 
        {
			var rotation = event.rotationRate;
			
            if (rotation != null) 
            {
				var hfov = viewer.getHFov() + ((-(Math.round(rotation.alpha) * DEG_TO_RAD) / 6));
				var pitch = viewer.getPitch() + ((-(Math.round(rotation.beta) * DEG_TO_RAD) / 4)) % Math.PI;
				var yaw = viewer.getYaw() + ((-(Math.round(rotation.gamma) * DEG_TO_RAD) / 4)) % (Math.PI * 2);

				viewer.setYaw(yaw);
				viewer.setPitch(pitch);
				viewer.setHFov(hfov);

				requestAnimationFrame();
			} 
		}
	}

	function onViewerDeviceOrientation(event) 
    {
		if (useDeviceOrientation) 
		{
            var alpha;
            
			if (event.webkitCompassHeading != undefined)
		    {
		        alpha = (360 - event.webkitCompassHeading);
		    }
		    else if (event.alpha != null)
		    {
		        alpha = (270 - event.alpha) * -1;
		    }
    
			alpha = Math.round(alpha);
            
			var beta = Math.round(event.beta);
			var gamma = Math.round(event.gamma);

			var yaw = (360 - alpha);
			var pitch = (Math.abs(gamma) - 90) ;
			
			viewer.setYaw(yaw  * DEG_TO_RAD);
			viewer.setPitch(pitch * DEG_TO_RAD);
            
			requestAnimationFrame();
		}
	}
    
    /**
    * Expects page coordinates
    */
    function down(x, y)
    {    
        isMoveInteracting = true;

        var p = getPagePosition(contentWrapper);
     
        startInteraction(x - p.x, y - p.y);
    }
    
    function move(x, y)
    {
        isZoomInteracting = false;
        
        var p = getPagePosition(contentWrapper);
        
        if(isMoveInteracting)
        {
            interact(x - p.x, y - p.y);
        }
    }
        
    function startInteraction(x, y)
    {        
        interactionDownX = x;
        interactionDownY = y;
        interactionDownPitch = viewer.getPitch();
        interactionDownYaw = viewer.getYaw();
    }
    
    function interact(x, y)
    {
        var yaw = (interactionDownX - x) * 0.2 * DEG_TO_RAD + interactionDownYaw;
		var pitch = (y - interactionDownY) * 0.2 * DEG_TO_RAD + interactionDownPitch;

		viewer.setYaw(yaw);
		viewer.setPitch(pitch);
    
        requestAnimationFrame();
    }
    
    
    // **************************************************************************************************
    // Viewer class functions
    // **************************************************************************************************
    
    function WebGLViewer(width, height)
    {
        // **************************************************************************************************
        // Viewer orientation, field of view, and camera parameters
        // **************************************************************************************************
        var yaw = 0.0;
        var pitch = 0.0;
        var hFov = Math.PI * 0.5;
                
        // **************************************************************************************************
        // Main canvas and GL context
        // **************************************************************************************************
        var canvas = document.createElement("canvas");
        canvas.setAttribute("style", cssPropertyPrefix + "user-select: none;");
        var gl = canvas.getContext("webgl") || canvas.getContext("experimental-webgl");
        
        // **************************************************************************************************
        // Initialize GL
        // **************************************************************************************************
        
        var programFlip;
        var programCube;
        var textureCube;
        var textureFace;
        // Used for "correcting" the input textures so that they can be stored in the cube map texture
        var framebuffer;
        
        var bufferCubeVertices;
        var bufferCubeVerticesIndex;
        var attrVertexPosition;
        
        // Contains the projection matrix reference and model view matrix reference
        var pUniform;
        var mvUniform;
        
        // Positive and negative orthogonal axis
        var px, nx, py, ny, pz, nz;

        initialize();
        
        function initialize()
        {
            initializeShaders();
            initializeTextures();
            initializeBuffers();
        }
        
        function initializeShaders()
        {
            var vsFlip = createShader(gl.VERTEX_SHADER, "\
            attribute mediump vec2 a_position;\
            attribute mediump vec2 a_texCoord;\
            \
            uniform mediump vec2 u_resolution;\
            \
            varying mediump vec2 v_texCoord;\
            \
            void main()\
            {\
                \
                vec2 zeroToOne = a_position / u_resolution;\
                \
                vec2 zeroToTwo = zeroToOne * 2.0;\
                \
                vec2 clipSpace = zeroToTwo - 1.0;\
                \
                gl_Position = vec4(clipSpace, 0, 1);\
                \
                v_texCoord = a_texCoord;\
            }");
            
            var fsFlip = createShader(gl.FRAGMENT_SHADER, "\
            uniform mediump sampler2D u_image;\
            \
            varying mediump vec2 v_texCoord;\
            \
            void main()\
            {\
                gl_FragColor = texture2D(u_image, v_texCoord);\
            }");
            
            programFlip = createProgram(vsFlip, fsFlip);
            
            var vsRender = createShader(gl.VERTEX_SHADER, "\
            attribute vec3 a_position;\
            \
            uniform mat4 u_MVMatrix;\
            uniform mat4 u_PMatrix;\
            \
            varying mediump vec3 v_texCoord;\
            \
            void main(void)\
            {\
                gl_Position = u_PMatrix * u_MVMatrix * vec4(a_position, 1.0);\
                v_texCoord = a_position;\
            }");
            
            var fsRender = createShader(gl.FRAGMENT_SHADER, "\
            varying mediump vec3 v_texCoord;\
            \
            uniform samplerCube u_image;\
            \
            void main(void) \
            {\
                gl_FragColor = textureCube(u_image, v_texCoord);\
            }");
            
            programCube = createProgram(vsRender, fsRender);
        }
                
        function createShader(type, source)
        {
            var shader = gl.createShader(type);
            
            gl.shaderSource(shader, source);
            gl.compileShader(shader);
            
            // See if it compiled successfully (tho this check is not realy required)
            if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) 
            {    
                alert("An error occurred compiling the shaders: " + gl.getShaderInfoLog(shader));    
                return null;
            }
            
            return shader;
        }
        
        function createProgram(vShader, fShader)
        {
            var program = gl.createProgram();  
            gl.attachShader(program, vShader);  
            gl.attachShader(program, fShader);  
            gl.linkProgram(program);  

            // Check if creating the shader program failed (tho this check is not realy required)
            if (!gl.getProgramParameter(program, gl.LINK_STATUS)) 
            {
                alert("Unable to initialize the shader program.");  
                return null;
            }
            
            return program;
        }
        
        function initializeTextures()
        {
            textureCube = createTextureCubeMap();
            textureFace = createTexture2D();
        }
        
        function createTextureCubeMap()
        {
            var texture = gl.createTexture();
            gl.bindTexture(gl.TEXTURE_CUBE_MAP, texture);
            
            gl.texParameteri(gl.TEXTURE_CUBE_MAP, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
            gl.texParameteri(gl.TEXTURE_CUBE_MAP, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
            gl.texParameteri(gl.TEXTURE_CUBE_MAP, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
            gl.texParameteri(gl.TEXTURE_CUBE_MAP, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
            gl.texParameteri(gl.TEXTURE_CUBE_MAP, gl.TEXTURE_WRAP_R, gl.CLAMP_TO_EDGE);

            //gl.texParameteri(gl.TEXTURE_CUBE_MAP, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_NEAREST);
            //gl.generateMipmap(gl.TEXTURE_CUBE_MAP);
            gl.bindTexture(gl.TEXTURE_CUBE_MAP, null);

            return texture;
        }
        
        function createTexture2D()
        {
            var texture = gl.createTexture();
            gl.bindTexture(gl.TEXTURE_2D, texture);
            //gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);
            gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
            gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
            gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
            gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
            
            gl.bindTexture(gl.TEXTURE_2D, null);
            
            return texture;
        }
                
        function initializeBuffers()
        {
            framebuffer = gl.createFramebuffer();
            
            createBuffersCube();
        }
                        
        function createBuffersCube()
        {
            // The cube.
            var vertices = [
                // Front face
                -1.0, -1.0,  1.0,
                1.0, -1.0,  1.0,
                1.0,  1.0,  1.0,
                -1.0,  1.0,  1.0,

                // Back face
                -1.0, -1.0, -1.0,
                -1.0,  1.0, -1.0,
                1.0,  1.0, -1.0,
                1.0, -1.0, -1.0,

                // Top face
                -1.0,  1.0, -1.0,
                -1.0,  1.0,  1.0,
                1.0,  1.0,  1.0,
                1.0,  1.0, -1.0,

                // Bottom face
                -1.0, -1.0, -1.0,
                1.0, -1.0, -1.0,
                1.0, -1.0,  1.0,
                -1.0, -1.0,  1.0,

                // Right face
                1.0, -1.0, -1.0,
                1.0,  1.0, -1.0,
                1.0,  1.0,  1.0,
                1.0, -1.0,  1.0,

                // Left face
                -1.0, -1.0, -1.0,
                -1.0, -1.0,  1.0,
                -1.0,  1.0,  1.0,
                -1.0,  1.0, -1.0
            ];
            
            // Create a buffer for the cube's vertices.
            bufferCubeVertices = gl.createBuffer();
            
            // A buffer object is created by binding an unused name to ARRAY_BUFFER.
            // While a buffer object is bound, GL operations on the target to which it is bound
            // affect the bound buffer object, and queries of the target to which a buffer object is
            // bound return state from the bound object.
            gl.bindBuffer(gl.ARRAY_BUFFER, bufferCubeVertices);
            
            // The data store of a buffer object is created and initialized by calling
            // bufferData with target set to ARRAY_BUFFER.
            
            // Thus we pass the list of vertices into WebGL to build the shape. We
            // do this by creating a Float32Array from the JavaScript array,
            // then use it to fill the current vertex buffer.
            gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertices), gl.STATIC_DRAW);
                
            // Build the element array buffer; this specifies the indices
            // into the vertex array for each face's vertices.
            bufferCubeVerticesIndex = gl.createBuffer();
            gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, bufferCubeVerticesIndex);
          
            // This array defines each face as two triangles, using the
            // indices into the vertex array to specify each triangle's
            // position.
            var vertexIndices = [
                0,  1,  2,      0,  2,  3,    // front
                4,  5,  6,      4,  6,  7,    // back
                8,  9,  10,     8,  10, 11,   // top
                12, 13, 14,     12, 14, 15,   // bottom
                16, 17, 18,     16, 18, 19,   // right
                20, 21, 22,     20, 22, 23    // left
            ];
          
            // Now send the element array to GL
            gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint16Array(vertexIndices), gl.STATIC_DRAW);
        }
        
        this.domElement = canvas;
        this.getYaw = function() { return yaw; }
        this.getPitch = function() { return pitch; }
        this.getHFov = function() { return hFov; }
        this.setYaw = function(value) { yaw = value; }
        this.setPitch = function(value) 
        { 
            if( value >= -Math.PI * 0.5 && value <= Math.PI * 0.5 )
                pitch = value; 
        }
        this.setHFov = function(value) 
        {
            if( value >= HFOV_MIN && value <= HFOV_MAX )
                hFov = value;
        }
                
        this.setCubeFaces = function(right, left, top, bottom, back, front) 
        {
            var width = right.width;
            var height = right.height;
            
            gl.bindTexture(gl.TEXTURE_CUBE_MAP, textureCube);            
            gl.texImage2D(gl.TEXTURE_CUBE_MAP_POSITIVE_X, 0, gl.RGBA, width, height, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
            gl.texImage2D(gl.TEXTURE_CUBE_MAP_NEGATIVE_X, 0, gl.RGBA, width, height, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
            gl.texImage2D(gl.TEXTURE_CUBE_MAP_POSITIVE_Y, 0, gl.RGBA, width, height, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
            gl.texImage2D(gl.TEXTURE_CUBE_MAP_NEGATIVE_Y, 0, gl.RGBA, width, height, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
            gl.texImage2D(gl.TEXTURE_CUBE_MAP_POSITIVE_Z, 0, gl.RGBA, width, height, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
            gl.texImage2D(gl.TEXTURE_CUBE_MAP_NEGATIVE_Z, 0, gl.RGBA, width, height, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
            gl.bindTexture(gl.TEXTURE_CUBE_MAP, null);
            
            gl.useProgram(programFlip);
            
            // Get references to argument values and uniform resource values.
            var a_position = gl.getAttribLocation(programFlip, "a_position");
            var a_texCoord = gl.getAttribLocation(programFlip, "a_texCoord");
            var u_resolution = gl.getUniformLocation(programFlip, "u_resolution");
            var u_image = gl.getUniformLocation(programFlip, "u_image");
            
            gl.uniform1i(u_image, 0);
            gl.uniform2f(u_resolution, width, height);
                        
            gl.bindFramebuffer(gl.FRAMEBUFFER, framebuffer);
            
            var faceRectangle = [
                0,      0,
                width,  0,
                0,      height,
                0,      height,
                width,  0,
                width,  height
            ];
            var faceTexCoordsHori = [
                1.0, 0.0,
                0.0, 0.0,
                1.0, 1.0,
                1.0, 1.0,
                0.0, 0.0,
                0.0, 1.0
            ];
            var faceTexCoordsVert = [
                0.0, 1.0,
                1.0, 1.0,
                0.0, 0.0,
                0.0, 0.0,
                1.0, 1.0,
                1.0, 0.0
            ];
                        
            // Create a buffer for the image rectangle (2 triangles)
            var bufferPosition = gl.createBuffer();
            gl.bindBuffer(gl.ARRAY_BUFFER, bufferPosition);
            gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(faceRectangle), gl.STATIC_DRAW);
            gl.enableVertexAttribArray(a_position);
            gl.vertexAttribPointer(a_position, 2, gl.FLOAT, false, 0, 0);
            
            var bufferTexCoordHori = gl.createBuffer();
            gl.bindBuffer(gl.ARRAY_BUFFER, bufferTexCoordHori);
            gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(faceTexCoordsHori), gl.STATIC_DRAW);
            
            var bufferTexCoordVert = gl.createBuffer();
            gl.bindBuffer(gl.ARRAY_BUFFER, bufferTexCoordVert);
            gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(faceTexCoordsVert), gl.STATIC_DRAW);
            
            setCubeFace(gl.TEXTURE_CUBE_MAP_POSITIVE_X, px = right, bufferTexCoordHori, a_texCoord);
            setCubeFace(gl.TEXTURE_CUBE_MAP_NEGATIVE_X, nx = left, bufferTexCoordHori, a_texCoord);
            setCubeFace(gl.TEXTURE_CUBE_MAP_POSITIVE_Y, py = top, bufferTexCoordVert, a_texCoord);
            setCubeFace(gl.TEXTURE_CUBE_MAP_NEGATIVE_Y, ny = bottom, bufferTexCoordVert, a_texCoord);
            setCubeFace(gl.TEXTURE_CUBE_MAP_POSITIVE_Z, pz = back, bufferTexCoordHori, a_texCoord);
            setCubeFace(gl.TEXTURE_CUBE_MAP_NEGATIVE_Z, nz = front, bufferTexCoordHori, a_texCoord);
            
            gl.bindFramebuffer(gl.FRAMEBUFFER, null);
            //gl.deleteBuffer(bufferPosition);
            //gl.deleteBuffer(bufferTexCoord);
            /**/
            
            gl.useProgram(programCube);
            
            pUniform = gl.getUniformLocation(programCube, "u_PMatrix");
            mvUniform = gl.getUniformLocation(programCube, "u_MVMatrix");
            gl.uniform1i(gl.getUniformLocation(programCube, "u_image"), 0);
            attrVertexPosition = gl.getAttribLocation(programCube, "a_position");
            
            this.render = renderCube;
        }
        
        function setCubeFace(texTarget, faceImage, bufferTexCoord, attribute)
        {
            // Set draw target
            gl.bindTexture(gl.TEXTURE_CUBE_MAP, textureCube);
            gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, texTarget, textureCube, 0);
            
            // Set draw source
            gl.bindTexture(gl.TEXTURE_2D, textureFace);
            gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, faceImage);
            
            gl.bindBuffer(gl.ARRAY_BUFFER, bufferTexCoord);
            gl.enableVertexAttribArray(attribute);
            gl.vertexAttribPointer(attribute, 2, gl.FLOAT, false, 0, 0);
            
            // Draw
            gl.viewport(0.0, 0.0, faceImage.width, faceImage.height);
            gl.drawArrays(gl.TRIANGLES, 0, 6);  
        }
                
        this.render = renderEmpty;
        
        function renderEmpty(width, height)
        {
            if(canvas.width !== width || canvas.height !== height)
            {
                canvas.width = width;
                canvas.height = height;
            }
        };
                                
        function renderCube(width, height)
        {
            if(canvas.width !== width || canvas.height !== height)
            {
                canvas.width = width;
                canvas.height = height;
            }
            
            gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);  
    
            var vFov = Math.atan( Math.tan(hFov * 0.5) * height / width ) * 2.0;
            var perspectiveMatrix = makePerspective(vFov * 180.0 / Math.PI, width/height, 0.1, 100.0);  
            var mvMatrix = Matrix.RotationX(-pitch).multiply(Matrix.RotationY(yaw)).ensure4x4()
            
            gl.bindBuffer(gl.ARRAY_BUFFER, bufferCubeVertices);
            gl.enableVertexAttribArray(attrVertexPosition);
            gl.vertexAttribPointer(attrVertexPosition, 3, gl.FLOAT, false, 0, 0); 
            
            gl.bindTexture(gl.TEXTURE_CUBE_MAP, textureCube);
                        
            gl.uniformMatrix4fv(pUniform, false, new Float32Array(perspectiveMatrix.flatten()));
            gl.uniformMatrix4fv(mvUniform, false, new Float32Array(mvMatrix.flatten()));
            
            gl.viewport(0.0, 0.0, width, height);
            gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, bufferCubeVerticesIndex);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
        }
        
    } // End of the WebGL viewer
        
    /**
    * Creates a viewer that renders each frame using CSS3 3D transforms.
    */
    function CSS3Viewer(width, height)
    {
        var RAD_TO_DEG = 180.0 / Math.PI;

        // **************************************************************************************************
        // Viewer orientation, field of view, and camera parameters
        // **************************************************************************************************
        var yaw = 0.0;
        var pitch = 0.0;
        var hFov = Math.PI * 0.5;
        var width_d2;
        var height_d2;
        var focalDistance;
        
        // **************************************************************************************************
        // Main context and cube content
        // **************************************************************************************************
        var divCubeContext = document.createElement("div");
        divCubeContext.setAttribute("style",
            "background : #0000ff; " +
            "overflow : hidden; " +
            cssPropertyPrefix + "user-select: none; " +
            cssPropertyPrefix + "transform-style : preserve-3d;"
        );
        
        // Because of a bug in Safari, the transform origin always has to be 0px 0px 0px, otherwise a change
        // in origin seems to cause a change in position/translate, resulting in perspective distortions.
        var divCube = document.createElement("div");
        divCube.setAttribute("style",
            "position : relative; " +
            cssPropertyPrefix + "user-select: none; " +
            cssPropertyPrefix + "transform-style : preserve-3d;" +
            cssPropertyPrefix + "transform-origin : 0px 0px 0px;"
        );
        
        divCubeContext.appendChild(divCube);
        
        // **************************************************************************************************
        // Cube face drawing
        // **************************************************************************************************
        var cubeSize;
        // Positive and negative orthogonal axis
        var px, nx, py, ny, pz, nz;
        
        // **************************************************************************************************
        // Set the correct style values after creation
        // **************************************************************************************************
        resize(width, height);
        
        function resize(width, height)
        {
            width_d2 = width * 0.5;
            height_d2 = height * 0.5;
            divCubeContext.style["width"] = width + "px";
            divCubeContext.style["height"] = height + "px";
            divCubeContext.style[stylePropertyPrefix + "PerspectiveOrigin"] = width_d2 + "px " + height_d2 + "px";
            
            updateOrientation();
        }

        function updateOrientation()
        {
            focalDistance = width_d2 / Math.tan(hFov * 0.5);
                
            divCubeContext.style[stylePropertyPrefix + "Perspective"] = focalDistance.toFixed(10) + "px";
            divCube.style[stylePropertyPrefix + "Transform"] = 
                "translate3d(" + width_d2 + "px, " + height_d2 + "px, " + focalDistance.toFixed(10) + "px) " +
                "rotateX(" + (pitch * RAD_TO_DEG).toFixed(10) + "deg) " +
                "rotateY(" + (yaw * RAD_TO_DEG).toFixed(10)+ "deg)";
        }
        
        this.domElement = divCubeContext;
        this.getYaw = function() { return yaw; }
        this.getPitch = function() { return pitch; }
        this.getHFov = function() { return hFov; }
        this.setYaw = function(value) { yaw = value; }
        this.setPitch = function(value) 
        { 
            if( value >= -Math.PI * 0.5 && value <= Math.PI * 0.5 )
                pitch = value; 
        }
        this.setHFov = function(value) 
        {
            if( value >= HFOV_MIN && value <= HFOV_MAX )
                hFov = value;
        }
        
        this.setCubeFaces = function(right, left, top, bottom, back, front) 
        {
            while (divCube.hasChildNodes()) 
            {
                divCube.removeChild(divCube.lastChild);
            }

            cubeSize = right.width;
            
            setCubeFaceCommon(px = right);
            setCubeFaceCommon(nx = left);
            setCubeFaceCommon(py = top);
            setCubeFaceCommon(ny = bottom);
            setCubeFaceCommon(pz = back);
            setCubeFaceCommon(nz = front);
            
            var cubeSize_d2 = 0.5 * cubeSize;
            var t = "translate3d(-" + cubeSize_d2 + "px, -" + cubeSize_d2 + "px, -" + cubeSize_d2 + "px)";
                    
            px.style[stylePropertyPrefix + "Transform"] = "rotateY(-90deg) " + t;
            nx.style[stylePropertyPrefix + "Transform"] = "rotateY(90deg) " + t;
            py.style[stylePropertyPrefix + "Transform"] = "rotateX(-90deg) " + t;
            ny.style[stylePropertyPrefix + "Transform"] = "rotateX(90deg) " + t;
            pz.style[stylePropertyPrefix + "Transform"] = "rotateY(180deg) " + t;
            nz.style[stylePropertyPrefix + "Transform"] = t;
        }
        
        function setCubeFaceCommon(cubeFace)
        {
            // Because of a bug in Safari, the transform origin always has to be 0px 0px 0px, otherwise a change
            // in origin seems to cause a change in position/translate, resulting in perspective distortions.
            cubeFace.setAttribute("style",
                "position : absolute; " +
                cssPropertyPrefix + "user-select: none; " +
                cssPropertyPrefix + "transform-style : preserve-3d;" +
                cssPropertyPrefix + "transform-origin : 0px 0px 0px;"
            );
            
            // This stops dragging of images which is truely anoying for the CSS3 version.
            cubeFace.draggable = false;
            // For the older web layout engines ...
            cubeFace.onmousedown = function(event) 
            {
                event.preventDefault();
            };
            
            divCube.appendChild(cubeFace);
        }
        
        this.render = function (width, height)
        {
            if(divCubeContext.style.width === width + "px" && divCubeContext.style.height === height + "px")
            {
                updateOrientation();
            }
            else
            {
                resize(width, height);
            }
        };
        
    }

    /**
    * Creates a viewer that renders each frame using per pixel sampling from a cube map.
    */
    function Canvas2DViewer(width, height)
    {
        // **************************************************************************************************
        // Viewer orientation and field of view
        // **************************************************************************************************
        var yaw = 0.0;
        var pitch = 0.0;
        var hFov = Math.PI / 2.0;
        
        // **************************************************************************************************
        // Main canvas and derived
        // **************************************************************************************************
        var canvas = document.createElement("canvas");
        canvas.setAttribute("style", cssPropertyPrefix + "user-select: none;");
        // A resize will replace the canvas context, imageData and imageBuffer
        var context = null;
        var imageData = null;
        var imageBuffer = null;
        
        // **************************************************************************************************
        // Cube face drawing
        // **************************************************************************************************
        var cubeSize;
        // Positive and negative orthogonal axis
        var px, nx, py, ny, pz, nz;
        
        // **************************************************************************************************
        // Initialize canvas and derived properties
        // **************************************************************************************************
        resize(width, height);
        
        function resize(width, height)
        {
            canvas.width = width;
            canvas.height = height;
            context = canvas.getContext("2d");
            context.fillStyle = "rgba(0, 0, 255, 1)";
            context.fillRect(0, 0, width, height);
            imageData = context.getImageData(0, 0, width, height);
            imageBuffer = imageData.data;
            //imageBuffer = new Int32Array(imageData.data.buffer);
        };
        
        function getImageBuffer(image)
        {
            var canvasFace = document.createElement("canvas");
            canvasFace.width = image.width;
            canvasFace.height = image.height;
            
            var contextFace = canvasFace.getContext("2d");
            contextFace.drawImage(image, 0, 0);
            
            var imageDataFace = contextFace.getImageData(0, 0, image.width, image.height);
            
            //return new Int32Array(imageDataFace.data.buffer);
            return imageDataFace.data;
        };
            
        this.domElement = canvas;
        this.getYaw = function() { return yaw; };
        this.getPitch = function() { return pitch; };
        this.getHFov = function() { return hFov; };
        this.setYaw = function(value) { yaw = value; }
        this.setPitch = function(value) 
        { 
            if( value >= -Math.PI * 0.5 && value <= Math.PI * 0.5 )
                pitch = value; 
        }
        this.setHFov = function(value) 
        {
            if( value >= HFOV_MIN && value <= HFOV_MAX )
                hFov = value;
        }
        
        // Images
        this.setCubeFaces = function(right, left, top, bottom, back, front)
        {
            cubeSize = right.width;
        
            px = getImageBuffer(right);
            nx = getImageBuffer(left);
            py = getImageBuffer(top);
            ny = getImageBuffer(bottom);
            pz = getImageBuffer(back);
            nz = getImageBuffer(front);
                            
            this.render = renderFaces;
        };
        
        this.render = renderEmpty;
        
        function renderEmpty(width, height)
        {
            if(canvas.width !== width || canvas.height !== height)
            {
                resize(width, height);
            }
        };
        
        function renderFaces(width, height)
        {
            if(canvas.width !== width || canvas.height !== height)
            {
                resize(width, height);
            }
            
            // Calculate coordinates in the coordinate axis similar to webgl.
            var pi = Math.PI;
            var pi_d2 = pi * 0.5;
            var cubeSize_d2 = cubeSize * 0.5;
            var ws = 2.0 * Math.tan(hFov * 0.5);
            var hs = height / width * ws;

            var cosYaw = -Math.cos(yaw);
            var sinYaw = Math.sin(yaw);
            
            var vCDX = sinYaw * Math.cos(pitch);
            var vCDY = Math.sin(pitch);
            var vCDZ = cosYaw * Math.cos(pitch);
            
            // The "up" vector
            var vCUX = sinYaw * Math.cos(pitch + pi_d2);
            var vCUY = Math.sin(pitch + pi_d2);
            var vCUZ = cosYaw * Math.cos(pitch + pi_d2);
            
            // The "right" vector
            var vCRX = vCDY * vCUZ - vCDZ * vCUY;
            var vCRY = vCDZ * vCUX - vCDX * vCUZ;
            var vCRZ = vCDX * vCUY - vCDY * vCUX;
            
            // Image origin (left upper corner of a pixel)
            var oX = vCDX - 0.5 * ws * vCRX + 0.5 * hs * vCUX;
            var oY = vCDY - 0.5 * ws * vCRY + 0.5 * hs * vCUY;
            var oZ = vCDZ - 0.5 * ws * vCRZ + 0.5 * hs * vCUZ;
                    
            var vCRX_step = (ws * vCRX) / width;
            var vCRY_step = (ws * vCRY) / width;
            var vCRZ_step = (ws * vCRZ) / width;
            
            var vCUX_step = (hs * vCUX) / height;
            var vCUY_step = (hs * vCUY) / height;
            var vCUZ_step = (hs * vCUZ) / height;
            
            var vSX = oX + 0.5 * (vCRX_step - vCUX_step);
            var vSY = oY + 0.5 * (vCRY_step - vCUY_step);
            var vSZ = oZ + 0.5 * (vCRZ_step - vCUZ_step);
            
            var dstIndex = 0;
            
            for(var j = 0; j < height; ++j)
            {
                var vX = vSX - j * vCUX_step;
                var vY = vSY - j * vCUY_step;
                var vZ = vSZ - j * vCUZ_step;
            
                for(var i = 0; i < width; ++i)
                {
                    var absX = vX < 0 ? -vX : vX;
                    var absY = vY < 0 ? -vY : vY;
                    var absZ = vZ < 0 ? -vZ : vZ;
                    var u;
                    var v;
                    var o;
                    var s;
                    
                    if(absX > absY && absX > absZ)
                    {
                        s = cubeSize_d2 / absX;
                        u = vZ * s;
                        v = vY * s;
                        
                        if(vX > 0)
                        {
                            o = px;
                        }
                        else
                        {
                            o = nx;
                            u = -u;
                        }
                    }
                    else if(absY > absZ)
                    {
                        s = cubeSize_d2 / absY;
                        u = vX * s;
                        v = vZ * s;
                        
                        if(vY > 0)
                        {
                            o = py;
                        }
                        else
                        {
                            o = ny;
                            v = -v;
                        }
                    }
                    else
                    {
                        s = cubeSize_d2 / absZ;
                        u = vX * s;
                        v = vY * s;
                        
                        if(vZ > 0)
                        {
                            o = pz;
                            u = -u;
                        }
                        else
                        {
                            o = nz;
                        }
                    }
                                            
                    // Y-coordinates are always flipped compared to images.
                    v = -v;
                    u = u + cubeSize_d2;
                    v = v + cubeSize_d2;
                    
                    var srcIndex = ((v & 0xffffffff) * cubeSize + (u & 0xffffffff)) * 4;
                    //var srcIndex = (Math.floor(v * cubeSize) * cubeSize + Math.floor(u * cubeSize));// * 4;
                                    
                    imageBuffer[dstIndex]     = o[srcIndex];
                    imageBuffer[dstIndex + 1] = o[srcIndex + 1];
                    imageBuffer[dstIndex + 2] = o[srcIndex + 2];
                    //imageBuffer[dstIndex + 3] = 255;
                
                    dstIndex += 4;// = (j * width + i);// * 4;
                    vX += vCRX_step;
                    vY += vCRY_step;
                    vZ += vCRZ_step;
                }   
            }
                    
            context.putImageData(imageData, 0, 0);
        };
    }   
    
}

//document.addEventListener("keydown", onDocumentKeyPress, false);
//document.addEventListener("onresize", onDocumentResize, false);
//document.addEventListener("mozfullscreenchange", onFullScreenChange, false);
//document.addEventListener("webkitfullscreenchange", onFullScreenChange, false);
//document.addEventListener("fullscreenchange", onFullScreenChange, false);
//document.addEventListener("mozfullscreenerror", fullScreenError, false);
//document.addEventListener("webkitfullscreenerror", fullScreenError, false);
//document.addEventListener("fullscreenerror", fullScreenError, false);
//window.addEventListener("resize", onDocumentResize, false);

// http://paulirish.com/2011/requestanimationframe-for-smart-animating/
// http://my.opera.com/emoller/blog/2011/12/20/requestanimationframe-for-smart-er-animating

// requestAnimationFrame polyfill by Erik M�ller
// fixes from Paul Irish and Tino Zijdel

(function() {
    var lastTime = 0;
    var vendors = ['ms', 'moz', 'webkit', 'o'];
    for(var x = 0; x < vendors.length && !window.requestAnimationFrame; ++x) {
        window.requestAnimationFrame = window[vendors[x]+'RequestAnimationFrame'];
        window.cancelAnimationFrame = window[vendors[x]+'CancelAnimationFrame']
                                   || window[vendors[x]+'CancelRequestAnimationFrame'];
    }
 
    if (!window.requestAnimationFrame)
        window.requestAnimationFrame = function(callback, element) {
            var currTime = new Date().getTime();
            var timeToCall = Math.max(0, 16 - (currTime - lastTime));
            var id = window.setTimeout(function() { callback(currTime + timeToCall); },
              timeToCall);
            lastTime = currTime + timeToCall;
            return id;
        };
 
    if (!window.cancelAnimationFrame)
        window.cancelAnimationFrame = function(id) {
            clearTimeout(id);
        };
}());


// http://www.kineticjs.com/ ?

function ArrowDrawer(canvas)
{
    var that = this;
    var cvs = canvas;
    var context = canvas.getContext("2d");
        
    // Points of the arrow (not rotated and aligned on the Y-axis in the coordinate 
    // system: Front = Y, Right = X, Up = Z).
    var arrowScale = 0.75;
    var arrowOffset = Vector.create([0.0, 4.0, -2.0]);
    var arrowPoints = [ 
        arrowOffset.add(Vector.create([ 0.0, 2.0, 0.0]).multiply(arrowScale)), 
        arrowOffset.add(Vector.create([ 1.0, 1.0, 0.0]).multiply(arrowScale)), 
        arrowOffset.add(Vector.create([ 0.5, 1.0, 0.0]).multiply(arrowScale)), 
        arrowOffset.add(Vector.create([ 1.0, 0.0, 0.0]).multiply(arrowScale)), 
        arrowOffset.add(Vector.create([-1.0, 0.0, 0.0]).multiply(arrowScale)), 
        arrowOffset.add(Vector.create([-0.5, 1.0, 0.0]).multiply(arrowScale)), 
        arrowOffset.add(Vector.create([-1.0, 1.0, 0.0]).multiply(arrowScale))
    ];
    /**/
    var recordings = new List();
    var projections = [];
    
    cvs.addEventListener("mousemove", onLayerMouseMove, false);
    cvs.addEventListener("mousedown", onLayerMouseDown, false);
    cvs.addEventListener("mouseup", onLayerMouseUp, false);
    
    function onLayerMouseMove(event)
    {
        var p = getPagePosition(cvs);
        var x = event.pageX - p.x;
        var y = event.pageY - p.y;
        var i;
        var count = recordings.Count();
        var updateLayer = false;
        
        for(i = 0; i < count; ++i)
        {
            if(projections[i].visible && !projections[i].highlight && pnpoly(projections[i].vertices, x, y))
            {
                projections[i].highlight = true;
                updateLayer = true;
            }
            else if(projections[i].highlight && !pnpoly(projections[i].vertices, x, y))
            {
                projections[i].highlight = false;
                updateLayer = true;
            }
        }
        
        if(updateLayer)
        {
            drawArrows();
        }
    }
    
    var mouseDownRecording;
    
    function onLayerMouseDown(event)
    {
        mouseDownRecording = null;
        
        var i;
        var count = recordings.Count();
        
        for(i = 0; i < count; ++i)
        {
            if(projections[i].highlight)
            {
                mouseDownRecording = recordings.ElementAt(i);
            }
        }
    }
    
    function onLayerMouseUp(event)
    {
        if(mouseDownRecording)
        {    
            var i;
            var count = recordings.Count();
            
            for(i = 0; i < count; ++i)
            {
                if(projections[i].highlight && mouseDownRecording == recordings.ElementAt(i))
                {
                    if(that.onmarkerclick)
                    {
                        that.onmarkerclick(recordings.ElementAt(i));
                    }
                    
                    //alert(recordings.ElementAt(i).id);
                }
            }
        }
    }
    
    this.onmarkerclick;
    this.camera = new Camera();
    this.setRecordings = function(rls)
    {
        recordings = rls;
        projections = [];
        
        var i;
        var count = recordings.Count();
        
        for(i = 0; i < count; ++i)
        {
            projections.push({ vertices : null, visible : false, highlight : false });
        }
    }
    
    this.getRecording = function(pixx, pixy)
    {
        var count = recordings.Count();
        var i;
        
        for(i = 0; i < count; ++i)
        {
            if(projections[i].visible && pnpoly(projections[i].vertices, pixx, pixy))
                return recordings.ElementAt(i);
        }
        
        return null;
    }
    
    function pnpoly(vertices, x, y)
    {
        var i, j, c = 0;
        var npol = vertices.length;

        for (i = 0, j = npol - 1; i < npol; j = i++) 
        {
            var xpi = vertices[i].elements[0];
            var ypi = vertices[i].elements[1];
            var xpj = vertices[j].elements[0];
            var ypj = vertices[j].elements[1];
        
            if ((((ypi <= y) && (y < ypj)) || ((ypj <= y) && (y < ypi))) && (x < (xpj - xpi) * (y - ypi) / (ypj - ypi) + xpi))
                c = !c;
        }
        
        return c;
    }
    
    function drawArrows()
    {
        var width = cvs.width;
        var height = cvs.height;
        var matrix = that.camera.projectionMatrix;
        var intrinsicMatrix = that.camera.intrinsicMatrix;
        var extrinsicMatrix = that.camera.extrinsicMatrix;
        var cameraPosition = that.camera.position;
        var count = recordings.Count();
                
        for(var i = 0; i < count; ++i)
        {
            var r = recordings.ElementAt(i).projectedPosition.subtract(cameraPosition);
            var p = matrix.multiply( r );
            var e = p.elements;
            
            if(e[2] > -1)
            {
                projections[i].visible = false;
                continue;
            }
            
            var x = e[0] / e[2];
            var y = e[1] / e[2];
            
            //if(x < 0 || x > width || y < 0 || y > height)
            //    continue;
            /*
            // Recording location projected
            context.fillStyle = "rgba(255, 0, 0, 1)";
            context.beginPath();
            context.arc(x, y, 10, 0, Math.PI * 2, true); 
            context.closePath();
            context.fill();
            /**/
            e = r.elements;
            
            // Rotation and projection of the navigation arrow
            var y = Math.atan2(e[0], e[1]);            
            var A = matrix.multiply(Matrix.RotationZ(-y));
            
            if(!projections[i].highlight)
            {
                context.fillStyle = "#80b3ff";
                context.strokeStyle = "#4d6b99";
            }
            else
            {
                context.fillStyle = "#90c3ff";
                context.strokeStyle = "#5d7ba9";
            }
            context.beginPath();
            context.lineJoin = "round";  
            context.lineWidth = 1.5;
            
            var j;
            var prjArrowPoints = new Array(7);
            var ignoreArrow = false;
                        
            for(j = 0; j < 7; ++j)
            {
                prjArrowPoints[j] = A.multiply(arrowPoints[j]);
                e = prjArrowPoints[j].elements;
                
                if(e[2] > -1)
                {
                    ignoreArrow = true;
                    break;
                }
            }
            
            if(ignoreArrow)
            {
                projections[i].visible = false;
                continue;
            }
            
            projections[i].visible = true;
            projections[i].vertices = [];
            
            // Draw arrow path
            prjArrowPoints[0] = prjArrowPoints[0].multiply(1.0 / prjArrowPoints[0].elements[2]);
            e = prjArrowPoints[0].elements;
            x = e[0];
            y = e[1];
            
            context.moveTo(x, y); 
                                    
            for(j = 1; j < 7; ++j)
            {
                prjArrowPoints[j] = prjArrowPoints[j].multiply(1.0 / prjArrowPoints[j].elements[2]);
                e = prjArrowPoints[j].elements;
                x = e[0];
                y = e[1];
                
                context.lineTo(x, y);
            }
            
            projections[i].vertices = prjArrowPoints;
            
            context.closePath();
            context.fill();
            context.stroke();
        }
        
    }
    
    
    this.draw = drawArrows;
    
    function Camera()
    {
        // Flip to go from SRS to camera coordinates
        var flip = Matrix.create
        ([
            [1.0,  0.0,  0.0],
            [0.0,  0.0, -1.0],
            [0.0, -1.0,  0.0]
        ]);
     
        var K = null;
        var f;
        var w;
        var h;
     
        this.yaw = 0.0;
        this.pitch = 0.0;
        this.hFov = Math.PI / 2.0;

        this.position = Vector.create([0.0, 0.0, 0.0]);
        this.extrinsicMatrix = Matrix.I(3);
        this.intrinsicMatrix = flip;
        this.projectionMatrix = Matrix.I(3);
        
        this.update = function(width, height, yaw_, pitch_, hFov_)
        {
            w = width;
            h = height;
            f = w / (2.0 * Math.tan(hFov_ * 0.5));
            yaw = yaw_;
            pitch = pitch_;
            hFov = hFov_;
            
            // A negative focus distance for using a negative Z axis as "front"
            K = Matrix.create
            ([
                [-f,  0.0, w * 0.5],
                [0.0,  -f, h * 0.5],
                [0.0, 0.0,       1]
            ]);
            
            // This assumes transposed points.
            this.intrinsicMatrix = K.multiply(flip); // Cheat
            this.extrinsicMatrix = Matrix.RotationX(-pitch).multiply(Matrix.RotationZ(yaw));
            this.projectionMatrix = this.intrinsicMatrix.multiply(this.extrinsicMatrix);
        }
    }
}

// This works for an element that has no padding (in the other case you might expect 
// different coordinates)
function getPagePosition(element)
{
    var pageLeft = 0.0;
    var pageTop = 0.0;
    
    if (element.offsetParent) 
    {
        do 
        {
            pageLeft += element.offsetLeft;
            pageTop += element.offsetTop;
        } 
        while (element = element.offsetParent);
        
        return { x: pageLeft, y: pageTop };
    }
    
    return undefined;
}